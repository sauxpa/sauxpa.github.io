#!/usr/bin/env python
# coding: utf-8

# We will work with gym environments... except there is a bug in the official library!
# Either clone and install from the following fork...
# !git clone https://github.com/mattmolinare/gym.git
# !cd gym && git pull && pip install -e .[full] > /dev/null 2>&1
# ... or fix the bug in your local library (see the commit report below)
# https://github.com/mattmolinare/gym/commit/225322d42bb35158de779931e1ec969c38b010aa

# Deep learning lib
# !pip install torch'

# !pip install ffmpeg-python > /dev/null 2>&1

# Packages required to show video
# !pip install pyvirtualdisplay > /dev/null 2>&1

# Other, non-Python packages are required to show video
# On Linux:
# sudo apt-get install -y xvfb libav-tools python-opengl ffmpeg


import sys
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import numpy as np
import random
from copy import deepcopy
import gym
from gym.wrappers import Monitor
from itertools import accumulate
from pyvirtualdisplay import Display
from IPython import display as ipythondisplay
from IPython.display import clear_output
from pathlib import Path
import base64

print("python : ", sys.version)
print("numpy :", np.__version__)
print("gym :", gym.__version__)
print("torch :", torch.__version__)


env = gym.make("CartPole-v0")
display = Display(visible=0, size=(1400, 900))
display.start()


def show_video():
    html = []
    for mp4 in Path("videos").glob("*.mp4"):
        video_b64 = base64.b64encode(mp4.read_bytes())
        html.append('''<video alt="{}" autoplay
                      loop controls style="height: 400px;">
                      <source src="data:video/mp4;base64,{}" type="video/mp4" />
                 </video>'''.format(mp4, video_b64.decode('ascii')))
    ipythondisplay.display(ipythondisplay.HTML(data="<br>".join(html)))


env = Monitor(env, './videos', force=True, video_callable=lambda episode: True)
done = False
state = env.reset()
while not done:
    action = np.random.randint(2)
    state, reward, done, info = env.step(action)
env.close()
show_video()
