import numpy as np
import time
import networkx as nx  # Requires version 2.5
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, Circle


colors = ['tab:blue', 'tab:red', 'tab:green', 'tab:orange', 'tab:purple', 'tab:brown', 'tab:pink', 'tab:gray',
          'tab:olive', 'tab:cyan']
layouts = {'spring': nx.spring_layout, 'shell': nx.shell_layout, 'spectral': nx.spectral_layout, 'fruchterman_reingold': nx.fruchterman_reingold_layout, 'kamada_kawai': nx.kamada_kawai_layout,
           'spiral': nx.spiral_layout, 'circular': nx.circular_layout,
           'linear': lambda G: {v: np.array([float(i), 0.]) for i, v in enumerate(G.nodes())}}


class GraphRenderer:
    def __init__(self, layout="spring"):
        self.initializedRender = False
        self.layout = layout
        self.screenshotpath = "screenshots/"

    def initRender(self, env, savefig=False):
        self.label = str(time.time())
        self.cpt = 0
        nS = env.nS
        scalearrow = nS
        scalepos = 10 * nS
        G = nx.MultiDiGraph(action=0, rw=0.)
        edge_labels = {}
        for state in env.states:
            for action in env.actions:
                for transition in env.P[state][action]:
                    proba = transition[0]
                    next_state = transition[1]
                    mu = env.R[state][action].mean()
                    G.add_edge(state, next_state, action=action, weight=proba, rw=env.R[state][action].mean())

        pos = layouts[self.layout](G)  # Dict of numpy array

        for x in env.states:
            pos[x] = [pos[x][0] * scalepos, pos[x][1] * scalepos]

        self.G = G
        self.pos = pos
        self.numFigure = plt.gcf().number

        plt.figure(self.numFigure)
        plt.clf()
        ax = plt.gca()

        nx.draw_networkx_nodes(G, pos, node_size=400,
                               node_color=['tab:gray' for v in G.nodes()])
        nx.draw_networkx_labels(G, pos, font_size=12, font_family='sans-serif')

        for u, v, d in G.edges(data=True):
            color = colors[d['action']]

            if u != v:
                pos_u = pos[u]
                pos_v = pos[v]
                ax.annotate('',
                            xy=pos_v, xycoords='data',
                            xytext=pos_u, textcoords='data',
                            arrowprops=dict(arrowstyle="->", color=color,
                                            shrinkA=10, shrinkB=10,
                                            patchA=None, patchB=None,
                                            connectionstyle="arc3,rad=rrr".replace('rrr', str(2. * d['weight'])),
                                            lw=1 + 3 * d['rw'],
                                            mutation_scale=15,
                                            ),
                            )
            else:
                pos_u = np.array(pos[u])
                pos_v = np.array(pos[v])
                pos_u[0] -= 10
                pos_v[0] += 10
                ax.annotate('',
                            xy=pos_v, xycoords='data',
                            xytext=pos_u, textcoords='data',
                            arrowprops=dict(arrowstyle="->", color=color,
                                            shrinkA=10, shrinkB=10,
                                            patchA=None, patchB=None,
                                            connectionstyle="arc3,rad=rrr".replace('rrr', str(5. * d['weight'])),
                                            lw=1 + 3 * d['rw'],
                                            mutation_scale=15,
                                            ),
                            )

        ax.autoscale()
        plt.axis('equal')
        plt.axis('off')
        plt.title('One color per action.\nThicker arrow = higher average reward.\nLonger arrow = higher probability.')
        if savefig:
            plt.savefig(self.screenshotpath+'discreteMDP-nx-'+self.label+'.png')
        plt.show(block=False)
        plt.pause(0.5)

    def render(self, env, current, lastaction, lastreward, savefig=False):
        """
            # Print the MDP in an image MDP.png, MDP.pdf
            # Node colors : orange = current state, gray = other states
            # Edge colors : the color indicates the corresponding action (e.g. blue= action 0, red = action 1, etc)
            # Edge transparency: indicates the probability with which we transit to that state.
            # Edge label: A label indicates a positive reward, with mean value given by the labal (color of the label = action)
            # Print also the MDP only shoinwg the rewards in MDPonlytherewards.pdg, MDPonlytherewards.pdf
            # Node colors : orange = current state, gray = other states
            # Edge colors : the color indicates the corresponding action (e.g. blue= action 0, red = action 1, etc)
            # Edge transparency: indicates the value of the mean reward.
            # Edge label: A label indicates a positive reward, with mean value given by the labal (color of the label = action)
            """
        if (not self.initializedRender):
            self.initRender(env, savefig=savefig)
            self.initializedRender = True

        plt.figure(self.numFigure)
        nx.draw_networkx_nodes(self.G, self.pos, node_size=400,
                               node_color=['tab:gray' if s != current else 'tab:orange' for s in self.G.nodes()])
        if savefig:
            plt.savefig(self.screenshotpath + 'discreteMDP-nx-' + self.label + "-"+str(self.cpt) + '.png')
        plt.show(block=False)
        plt.pause(0.01)
        self.cpt += 1
