import numpy as np
from learners.discreteMDPs.utils import allmax, categorical_sample


class OptimalControl:
    def __init__(self, env, epsilon=1e-4, max_iter=1000, gamma=0.99):
        self.env = env
        self.nS = self.env.nS
        self.nA = self.env.nA
        self.u = np.zeros(self.nS)
        self.epsilon = epsilon
        self.max_iter = max_iter
        self.gamma = gamma
        self.name = 'Optimal-control'

        self.not_converged = True
        self.transitions = np.zeros((self.nS, self.nA, self.nS))
        self.meanrewards = np.zeros((self.nS, self.nA))
        self.policy = np.zeros((self.nS, self.nA))

        for s in range(self.nS):
            for a in range(self.nA):
                self.transitions[s, a] = self.env.getTransition(s, a)
                self.meanrewards[s, a] = self.env.getMeanReward(s, a)
                self.policy[s, a] = 1. / self.nA

        self.VI(epsilon=self.epsilon, max_iter=self.max_iter)

    def reset(self, inistate):
        ()

    def play(self, state):
        a = categorical_sample([self.policy[state, a] for a in range(self.nA)], np.random)
        return a

    def update(self, state, action, reward, observation):
        ()

    def VI(self, epsilon=1e-4, max_iter=1000):
        u0 = np.zeros(self.nS)
        u1 = np.zeros(self.nS)
        itera = 0
        while True:
            for s in range(self.nS):
                for a in range(self.nA):
                    # TODO
                u1[s] = # TODO
                # Note: allmax(v) returns (max(v), argmax(v)), where argmax(v) is a list

                # when multiple actions lead to the same value, uniformly choose between them
                self.policy[s] = # TODO

            diff = [abs(x - y) for (x, y) in zip(u1, u0)]
            if max(diff) < epsilon:
                self.u = u1
                break
            elif itera > max_iter:
                self.u = u1
                print('No convergence in VI before ' + str(max_iter) + ' iterations.')
                break
            else:
                u0 = u1
                u1 = np.zeros(self.nS)
                itera += 1
