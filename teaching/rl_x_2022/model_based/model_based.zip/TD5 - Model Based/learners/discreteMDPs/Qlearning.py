import numpy as np
from learners.discreteMDPs.utils import categorical_sample, allmax


class Qlearning:
    def __init__(self, env, gamma=0.99):
        self.env = env.env
        self.nS = self.env.nS
        self.nA = self.env.nA
        self.Q = np.zeros((self.nS, self.nA))
        self.policy = np.zeros((self.nS, self.nA))
        self.alpha = np.zeros((self.nS, self.nA))
        self.gamma = gamma
        self.name = 'Q-learning'

    def reset(self, inistate):
        for s in range(self.nS):
            for a in range(self.nA):
                self.Q[s, a] = 0.0
                self.policy[s, a] = 1. / self.nA
                self.alpha[s, a] = 1.

    def play(self, state):
        action = categorical_sample([self.policy[state, a] for a in range(self.nA)], np.random)
        return action

    def update(self, state, action, reward, observation):
        self.Q[state, action] = # TODO
        (v, arg) = allmax(self.Q[state])
        # Note: allmax(v) returns (max(v), argmax(v)), where argmax(v) is a list

        # when multiple actions lead to the same value, uniformly choose between them
        self.policy[state] = # TODO
