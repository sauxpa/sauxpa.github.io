import numpy as np
from learners.discreteMDPs.utils import categorical_sample, allmax


class Qlearning:
    def __init__(self, env, gamma=0.99, init_Q=0.0, epsilon=0.01):
        self.env = env.env
        self.nS = self.env.nS
        self.nA = self.env.nA
        self.Q = np.zeros((self.nS, self.nA))
        self.policy = np.zeros((self.nS, self.nA))
        self.alpha = np.zeros((self.nS, self.nA))
        self.gamma = gamma
        self.init_Q = init_Q
        self.epsilon = epsilon
        self.name = 'Q-learning'

    def reset(self, inistate):
        for s in range(self.nS):
            for a in range(self.nA):
                # Optimistic initialization: crucial for good performances.
                self.Q[s, a] = self.init_Q
                self.policy[s, a] = 1. / self.nA
                self.alpha[s, a] = 1.

    def play(self, state):
        if np.random.rand() < self.epsilon:
            action = np.random.randint(self.nA)
        else:
            action = categorical_sample([self.policy[state, a] for a in range(self.nA)], np.random)
        return action

    def update(self, state, action, reward, observation):
        self.Q[state, action] = self.Q[state, action] + self.alpha[state, action] * (reward + self.gamma * max(self.Q[observation]) - self.Q[state, action])
        self.alpha[state, action] = 1. / (1. / self.alpha[state, action] + 1.)
        (u, arg) = allmax(self.Q[state])
        self.policy[state] = [1. / len(arg) if x in arg else 0 for x in range(self.nA)]
