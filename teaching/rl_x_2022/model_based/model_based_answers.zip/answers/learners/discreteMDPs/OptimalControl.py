import numpy as np
from learners.discreteMDPs.utils import allmax, categorical_sample


class OptimalControl:
    def __init__(self, env, epsilon=1e-4, max_iter=1000, gamma=0.99, stochastic_policy=True):
        self.env = env
        self.nS = self.env.nS
        self.nA = self.env.nA
        self.v = np.zeros(self.nS)
        self.epsilon = epsilon
        self.max_iter = max_iter
        self.gamma = gamma
        self.stochastic_policy = stochastic_policy
        self.name = 'Optimal-control'

        self.not_converged = True
        self.transitions = np.zeros((self.nS, self.nA, self.nS))
        self.meanrewards = np.zeros((self.nS, self.nA))
        self.policy = np.zeros((self.nS, self.nA))

        self.v_history = np.zeros((self.max_iter, self.nS))
        self.policy_history = np.zeros((self.max_iter, self.nS, self.nA))

        for s in range(self.nS):
            for a in range(self.nA):
                self.transitions[s, a] = self.env.getTransition(s, a)
                self.meanrewards[s, a] = self.env.getMeanReward(s, a)
                self.policy[s, a] = 1. / self.nA

        self.VI(epsilon=self.epsilon, max_iter=self.max_iter)

    def reset(self, inistate):
        ()

    def play(self, state):
        a = categorical_sample([self.policy[state, a] for a in range(self.nA)], np.random)
        return a

    def update(self, state, action, reward, observation):
        ()

    def VI(self, epsilon=1e-4, max_iter=1000):
        v0 = np.zeros(self.nS)
        v1 = np.zeros(self.nS)
        itera = 0
        while True:
            for s in range(self.nS):
                temp = np.zeros(self.nA)
                for a in range(self.nA):
                    temp[a] = self.meanrewards[s, a] + self.gamma * sum([v0[ns] * self.transitions[s, a, ns] for ns in range(self.nS)])
                (v1[s], choice) = allmax(temp)
                # when multiple actions lead to the same value, either
                # uniformly choose between them (stochastic policy)
                # or choose a single action (deterministic policy).
                if not self.stochastic_policy:
                    choice = [choice[np.random.randint(len(choice))]]
                self.policy[s] = [1. / len(choice) if x in choice else 0 for x in range(self.nA)]


            self.v_history[itera] = v1
            self.policy_history[itera] = self.policy

            diff = [abs(x - y) for (x, y) in zip(v1, v0)]
            if max(diff) < epsilon:
                self.v = v1
                break
            elif itera > max_iter:
                self.v = v1
                print('No convergence in VI before ' + str(max_iter) + ' iterations.')
                break
            else:
                v0 = v1
                v1 = np.zeros(self.nS)
                itera += 1

        self.v_history = self.v_history[:itera + 1]
        self.policy_history = self.policy_history[:itera + 1]
