import numpy as np
import learners.discreteMDPs.utils as utils


class Agent:
    def __init__(self, env, name="Agent"):
        self.env = env.env
        self.nS = self.env.nS
        self.nA = self.env.nA
        self.name = name

    def reset(self,inistate):
        ()

    def play(self,state):
        return np.random.randint(self.nA)

    def update(self, state, action, reward, observation):
        ()
