"""
This file contains methods to register several MDP environments into gym.
Name of environments should not contain symbol '_'.

"""
from gym.envs.registration import register
import numpy as np


def registerRandomMDP(nbStates=5, nbActions=4, max_steps=np.infty, reward_threshold=np.infty, maxProportionSupportTransition=0.5, maxProportionSupportReward=0.1, maxProportionSupportStart=0.2, minNonZeroProbability=0.2, minNonZeroReward=0.3, rewardStd=0.5, seed=None):
    name = 'RandomMDP-'+str(nbStates)+'-v0'
    register(
        id=name,
        entry_point='environments.discreteMDPs.envs.RandomMDP:RandomMDP',
        max_episode_steps=max_steps,
        reward_threshold=reward_threshold,
        kwargs={'nbStates': nbStates, 'nbActions': nbActions, 'maxProportionSupportTransition': maxProportionSupportTransition, 'maxProportionSupportReward': maxProportionSupportReward,
                'maxProportionSupportStart': maxProportionSupportStart, 'minNonZeroProbability': minNonZeroProbability, 'minNonZeroReward': minNonZeroReward, 'rewardStd': rewardStd, 'seed': seed, 'name': name}
    )
    return name


def registerRiverSwim(nbStates=5, max_steps=np.infty, reward_threshold=np.infty, rightProbaright=0.6, rightProbaLeft=0.05, rewardL=0.1, rewardR=1.):
    name = 'RiverSwim-'+str(nbStates)+'-v0'
    register(
        id=name,
        entry_point='environments.discreteMDPs.envs.RiverSwim:RiverSwim',
        max_episode_steps=max_steps,
        reward_threshold=reward_threshold,
        kwargs={'nbStates': nbStates, 'rightProbaright': rightProbaright, 'rightProbaLeft': rightProbaLeft,
                'rewardL': rewardL, 'rewardR': rewardR, 'name': name}
    )
    return name


def registerGridworld(sizeX=10, sizeY=10, map_name="4-room", rewardStd=0., initialSingleStateDistribution=False, max_steps=np.infty, reward_threshold=np.infty):
    name = 'Gridworld-'+map_name+'-v0'
    register(
        id=name,
        entry_point='environments.discreteMDPs.envs.GridWorld.gridworld:GridWorld',
        max_episode_steps=max_steps,
        reward_threshold=reward_threshold,
        kwargs={'sizeX': sizeX, 'sizeY': sizeY, 'map_name': map_name, 'rewardStd': rewardStd, 'initialSingleStateDistribution': initialSingleStateDistribution, 'name': name}
    )
    return name


def registerThreeState(delta=0.005, max_steps=np.infty, reward_threshold=np.infty, fixed_reward=True):
    name = 'ThreeState-v0'
    register(
        id=name,
        entry_point='environments.discreteMDP:ThreeState',
        max_episode_steps=max_steps,
        reward_threshold=reward_threshold,
        kwargs={'delta': delta, 'fixed_reward': fixed_reward, 'name': name}
    )
    return name


registerWorlds = {
    "random-rich": lambda x: registerRandomMDP(nbStates=10, nbActions=4, maxProportionSupportTransition=0.12,
                                               maxProportionSupportReward=0.8, maxProportionSupportStart=0.1,
                                               minNonZeroProbability=0.15, minNonZeroReward=0.4, rewardStd=0.1, seed=10),
    "random-10": lambda x: registerRandomMDP(nbStates=12, nbActions=2, maxProportionSupportTransition=0.15, maxProportionSupportReward=0.25, maxProportionSupportStart=0.1, minNonZeroProbability=0.15, minNonZeroReward=0.3, rewardStd=0.1, seed=5),
    "random-100": lambda x: registerRandomMDP(nbStates=100, nbActions=3, maxProportionSupportTransition=0.1, maxProportionSupportReward=0.1, maxProportionSupportStart=0.1, minNonZeroProbability=0.15, minNonZeroReward=0.3, rewardStd=0.1, seed=10),
    "three-state": lambda x: registerThreeState(delta=0.005),
    "river-swim-6": lambda x: registerRiverSwim(nbStates=6, rightProbaright=0.4, rightProbaLeft=0.05, rewardL=0.005, rewardR=1.),
    "river-swim-25": lambda x: registerRiverSwim(nbStates=25, rightProbaright=0.4, rightProbaLeft=0.05, rewardL=0.005, rewardR=1.),
    "grid-random": lambda x: registerGridworld(sizeX=8, sizeY=5, map_name="random", rewardStd=0.01, initialSingleStateDistribution=True),
    "grid-2-room": lambda x: registerGridworld(sizeX=9, sizeY=11, map_name="2-room", rewardStd=0.0, initialSingleStateDistribution=True),
    "grid-4-room": lambda x: registerGridworld(sizeX=7, sizeY=7, map_name="4-room", rewardStd=0.0, initialSingleStateDistribution=True)
}


def registerWorld(envName):
    if (envName in registerWorlds.keys()):
        regName = (registerWorlds[envName])(0)
        print("[INFO] Environment " + envName + " registered as " + regName)
        return regName
